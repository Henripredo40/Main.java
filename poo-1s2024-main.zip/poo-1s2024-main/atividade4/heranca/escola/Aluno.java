package atividade4.heranca.escola;

public class Aluno {
   
    protected String nome;
    protected Integer matricula;
    protected Integer telefone;
    private String turma;
    protected String turno;
    

    public String getNome() {
        return this.nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getMatricula() {
        return this.matricula;
    }

    public void setMatricula(Integer matricula) {
        this.matricula = matricula;
    }

    public Integer getTelefone() {
        return this.telefone;
    }

    public void setTelefone(Integer telefone) {
        this.telefone = telefone;
    }

    public Varchar getTurma() {
        return this.turma;
    }

    public void setTurma(Varchar turma) {
        this.turma = turma;
    }

    public String getTurno() {
        return this.turno;
    }

    public void setTurno(String turno) {
        this.turno = turno;
    }


    }
    
       
    


